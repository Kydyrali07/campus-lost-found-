<?php
// Core of the site: database connection, sessions, security helpers and page layout.
declare(strict_types=1);

session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'secure' => !empty($_SERVER['HTTPS'])]);
if (session_status() === PHP_SESSION_NONE) session_start();
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header("Content-Security-Policy: default-src 'self' https: data: 'unsafe-inline' 'unsafe-eval'; img-src 'self' data: https: blob:; font-src 'self' https://fonts.gstatic.com data:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://unpkg.com; script-src 'self' 'unsafe-inline' https://unpkg.com; form-action 'self'");

// ---------- database (PDO, prepared statements only)
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $c = require __DIR__ . '/../config.php';
        try {
            $pdo = new PDO("mysql:host={$c['host']};port={$c['port']};dbname={$c['name']};charset=utf8mb4", $c['user'], $c['pass'], [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::MYSQL_ATTR_FOUND_ROWS   => true,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            exit('<h2>Cannot connect to the database.</h2><p>Start MySQL in the XAMPP Control Panel, then open <a href="install.php">install.php</a> to create the database.</p>');
        }
    }
    return $pdo;
}

// ---------- small helpers
function e($v): string { return htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function redirect(string $url) { header('Location: ' . $url); exit; }
function flash(string $msg, string $type = 'ok'): void { $_SESSION['flash'][] = [$type, $msg]; }
function csrf_token(): string { return $_SESSION['csrf'] ??= bin2hex(random_bytes(32)); }
function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">'; }
function csrf_check(): void
{
    if (!hash_equals($_SESSION['csrf'] ?? '', (string) ($_POST['csrf'] ?? ''))) {
        http_response_code(419);
        exit('Invalid request token. Go back, reload the page and try again.');
    }
}
function is_post(): bool { return $_SERVER['REQUEST_METHOD'] === 'POST'; }
function safe_next(?string $n): string { return ($n && preg_match('/^[a-z_]+\.php(\?[\w=&%.\-]*)?$/', $n)) ? $n : 'index.php'; }

function relative_date(string $dateStr): string
{
    try {
        $d = new DateTime($dateStr);
        $today = new DateTime('today');
        $interval = $today->diff($d);
        if ($interval->days === 0 && $interval->invert === 0) return 'Today';
        if ($interval->days === 1 && $interval->invert === 1) return 'Yesterday';
        if ($interval->days > 1 && $interval->days < 14 && $interval->invert === 1) return $interval->days . ' days ago';
        return $d->format('M j, Y');
    } catch (Throwable $e) {
        return $dateStr;
    }
}

function location_label(?string $building, ?string $place): string
{
    $place = trim((string) $place);
    $building = trim((string) $building);
    if ($building === 'Library' || $place === 'Library' || stripos($place, 'Library') !== false) return 'Library';
    if ($place === 'Bus Stop') return 'Bus Stop';
    if ($place === 'Canteen') return 'Canteen';
    $clean = preg_replace('/^Lecture Hall\s+/i', 'Room ', $place);
    if (!empty($clean) && $clean !== $building) return $clean;
    return $building ?: ($place ?: 'Campus');
}

// ---------- authentication / authorisation
function user(): ?array { return $_SESSION['user'] ?? null; }
function require_login(): array
{
    $u = user();
    if (!$u) {
        flash('Please log in first.', 'err');
        $self = basename($_SERVER['SCRIPT_NAME']) . (($_SERVER['QUERY_STRING'] ?? '') !== '' ? '?' . $_SERVER['QUERY_STRING'] : '');
        redirect('login.php?next=' . urlencode($self));
    }
    $st = db()->prepare('SELECT is_blocked FROM users WHERE user_id = ?');
    $st->execute([$u['id']]);
    $row = $st->fetch();
    if (!$row || (int) $row['is_blocked'] === 1) { unset($_SESSION['user']); flash('This account is blocked or no longer exists.', 'err'); redirect('login.php'); }
    return $u;
}
function require_admin(): array
{
    $u = require_login();
    if ($u['role'] !== 'admin') { flash('Admins only.', 'err'); redirect('index.php'); }
    return $u;
}
// 10 attempts per 15 minutes per IP (stored in a temp file)
function rate_limited(): bool
{
    $file = sys_get_temp_dir() . '/lf_rate_' . md5($_SERVER['REMOTE_ADDR'] ?? 'cli') . '.json';
    $now = time();
    $hits = is_file($file) ? (json_decode((string) file_get_contents($file), true) ?: []) : [];
    $hits = array_values(array_filter($hits, fn($t) => $now - $t < 900));
    if (count($hits) >= 10) return true;
    $hits[] = $now;
    file_put_contents($file, json_encode($hits), LOCK_EX);
    return false;
}

// ---------- layout
function page_header(string $title, string $active = ''): void
{
    $u = user(); $unread = 0;
    if ($u) {
        $st = db()->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0');
        $st->execute([$u['id']]);
        $unread = (int) $st->fetchColumn();
    }
    $nav = static fn(string $href, string $label, string $key) =>
        '<a href="' . $href . '" class="nav-item' . ($active === $key ? ' active' : '') . '">' . $label . '</a>';

    echo '<!doctype html><html lang="en"><head><meta charset="utf-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . e($title) . ' | Campus Lost &amp; Found</title>';
    echo '<link rel="icon" type="image/svg+xml" href="assets/logo.svg">';
    echo '<link rel="preconnect" href="https://fonts.googleapis.com">';
    echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>';
    echo '<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">';
    echo '<link rel="stylesheet" href="assets/style.css?v=' . filemtime(__DIR__ . '/../assets/style.css') . '">';
    echo '<style>' . file_get_contents(__DIR__ . '/../assets/style.css') . '</style>';
    echo '</head><body>';

    
    echo '<header class="top-nav"><div class="nav-container">';
    echo '<div class="nav-left">';
    echo '<a class="nav-brand" href="index.php"><img src="assets/logo.svg" alt="Campus Lost &amp; Found home" width="28" height="28" style="vertical-align:middle;margin-right:8px;border-radius:6px;">Campus Lost &amp; Found</a>';
    echo '<nav class="nav-links">';
    echo $nav('index.php', 'Feed', 'feed');
    echo $nav('my.php', 'My posts' . ($unread ? ' <span class="badge-count">' . $unread . '</span>' : ''), 'my');
    echo $nav('map.php', 'Campus map', 'map');
    if ($u && $u['role'] === 'admin') {
        echo $nav('admin.php', 'Admin', 'admin');
    }
    echo '</nav></div>';

    echo '<div class="nav-right">';
    echo '<a href="post.php" class="btn-post-action">Post an item</a>';
    if ($u) {
        echo '<div class="nav-user">';
        echo '<span class="user-email-text" title="' . e($u['name']) . '">' . e($u['email'] ?? $u['name']) . '</span>';
        echo '<form method="post" action="logout.php" class="logout-form">' . csrf_field();
        echo '<button class="btn-logout" title="Log out">Log out</button></form>';
        echo '</div>';
    } else {
        echo '<div class="nav-auth">';
        echo '<a class="btn-auth ghost" href="login.php">Log in</a>';
        echo '<a class="btn-auth" href="register.php">Register</a>';
        echo '</div>';
    }
    echo '</div></div></header>';

    echo '<main class="main-content">';
    foreach ($_SESSION['flash'] ?? [] as [$type, $msg]) {
        echo '<div class="flash-alert flash-' . e($type) . '">' . e($msg) . '</div>';
    }
    unset($_SESSION['flash']);
}

function page_footer(): void
{
    echo '</main>';
    echo '<footer class="footer"><div class="footer-container">';
    echo '<div class="footer-left"><b>Campus Lost &amp; Found</b> &middot; Astana IT University &middot; ICT Platform</div>';
    echo '<div class="footer-links"><a href="index.php">Feed</a><a href="map.php">Campus Map</a><a href="post.php">Post an item</a></div>';
    echo '</div></footer>';
    echo '<script src="assets/app.js"></script></body></html>';
}

function photo_html(?array $i, string $cls = 'ph'): string
{
    if (!empty($i['photo_url']) && preg_match('#^uploads/[a-f0-9]+\.(jpg|png|webp)$#', $i['photo_url']) && file_exists(__DIR__ . '/../' . $i['photo_url'])) {
        $alt = e($i['title'] ?? 'Item photo');
        return '<img class="' . $cls . '" src="' . e($i['photo_url']) . '" alt="' . $alt . '" loading="lazy">';
    }
    return '<div class="' . $cls . ' empty" role="img" aria-label="No photo available"><svg class="ph-placeholder-svg" width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="3.5"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg></div>';
}

function tag_html(string $type): string
{
    $t = strtolower($type);
    if ($t === 'lost') return '<span class="tag tag-lost">Lost</span>';
    if ($t === 'found') return '<span class="tag tag-found">Found</span>';
    return '<span class="tag tag-resolved">Resolved</span>';
}
