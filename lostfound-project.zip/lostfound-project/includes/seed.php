<?php
// Test data generator: 120 items + 10..60 rows in every other table. Used by install.php.
declare(strict_types=1);

function seed_database(PDO $pdo): array
{
    mt_srand(20261013);                                              // reproducible data
    $pick = fn(array $a) => $a[mt_rand(0, count($a) - 1)];
    $daysAgo = fn(int $n) => (new DateTime())->modify("-$n days")->modify('-' . mt_rand(0, 86000) . ' seconds');
    $ts = fn(DateTime $d) => $d->format('Y-m-d H:i:s');
    $dt = fn(DateTime $d) => $d->format('Y-m-d');

    $first = ['Aigerim','Dana','Aruzhan','Madina','Aliya','Zhanar','Ayana','Nurlan','Yerlan','Daniyar','Arman','Timur','Bekzat','Aidos','Alisher','Sanzhar','Miras','Dias','Kamila','Assel'];
    $last  = ['Akhmetov','Serikbayev','Nurgaliyev','Kassymov','Omarov','Zhaksylykov','Tulegenov','Bekov','Sadykov','Mukhametov','Abenov','Kaliyev'];
    $categories = ['Electronics','Cards/IDs','Clothing','Keys','Bags','Books & Notes','Accessories','Sports Gear','Documents','Other'];
    $locs = [
      ['Main Building','Lobby',51.0897,71.4172],
      ['Main Building','Canteen',51.0895,71.4168],
      ['Main Building','Lecture Hall C1.1.274',51.0899,71.4170],
      ['Main Building','Lecture Hall C1.2.130',51.0898,71.4175],
      ['Library','Reading Room',51.0894,71.4174],
      ['Library','Entrance',51.0893,71.4173],
      ['Dormitory','Lobby',51.0908,71.4192],
      ['Dormitory','Laundry Room',51.0909,71.4194],
      ['Sports Hall','Locker Room',51.0888,71.4182],
      ['Sports Hall','Gym',51.0889,71.4184],
      ['Campus','Bus Stop',51.0891,71.4152],
      ['Campus','Parking',51.0904,71.4165],
      ['Campus','Courtyard',51.0897,71.4178],
      ['Security Desk','Main Entrance',51.0896,71.4169],
      ['Coworking','Open Space',51.0898,71.4176]
    ];
    $things = [
      'Electronics'   => [['AirPods case','White case with a small scratch'],['Wired headphones','Black over-ear headphones'],['Power bank','10000 mAh, blue'],['USB-C charger','65W laptop charger'],['Smartwatch','Black strap, cracked corner']],
      'Cards/IDs'     => [['Student ID card','Astana IT University card'],['Bank card','Kaspi Gold card'],['Library card','Blue library card'],['Transport card','Astana bus card']],
      'Clothing'      => [['Black jacket','Zip jacket, size M'],['Grey hoodie','Hoodie with a white logo'],['Winter scarf','Red wool scarf'],['Gloves','Black leather gloves']],
      'Keys'          => [['Apartment keys','Three keys with a blue tag'],['Dorm room key','Key with number 214'],['Car key','Toyota key with remote']],
      'Bags'          => [['Blue backpack','Blue backpack with a laptop pocket'],['Black tote bag','Canvas tote bag'],['Pencil case','Green pencil case']],
      'Books & Notes' => [['Calculus textbook','Textbook with yellow notes'],['Notebook','Black notebook, ICT lectures'],['Algorithms book','Cormen, hardcover']],
      'Accessories'   => [['Glasses','Black frame glasses in a case'],['Silver ring','Thin silver ring'],['Water bottle','Steel bottle with stickers'],['Umbrella','Black folding umbrella']],
      'Sports Gear'   => [['Gym shoes','White sneakers size 42'],['Football','Training ball'],['Sports bottle','Orange bottle']],
      'Documents'     => [['Passport cover','Brown cover, no documents'],['Folder with papers','Blue folder, course work']],
      'Other'         => [['Flash drive','32 GB silver flash drive'],['Calculator','Casio scientific calculator'],['Wallet','Brown leather wallet']],
    ];
    $msgs = ['Hi, I think this is my item. Can we meet at the library?','Is it still available? I lost it yesterday.','Thank you for finding it! Where can I pick it up?','The description matches mine, there is a sticker on the back.','I can bring it to the security desk tomorrow morning.','Please confirm the color and any distinctive marks.','Great, I will come after the 3 pm lecture.','This is not mine, sorry. Good luck with the search!'];
    $reasons = ['Spam advertisement','Inappropriate description','Duplicate listing','Suspicious contact request','Wrong category'];

    $insert = function (string $table, array $cols, array $rows) use ($pdo): void {
        $st = $pdo->prepare("INSERT INTO $table (" . implode(', ', $cols) . ') VALUES (' . implode(', ', array_fill(0, count($cols), '?')) . ')');
        $pdo->beginTransaction();
        foreach ($rows as $r) $st->execute($r);
        $pdo->commit();
    };

    $studentHash = password_hash('Student#2026', PASSWORD_BCRYPT, ['cost' => 12]);
    $adminHash   = password_hash('Admin#2026', PASSWORD_BCRYPT, ['cost' => 12]);

    $insert('categories', ['name'], array_map(fn($c) => [$c], $categories));
    $insert('locations', ['building', 'place', 'latitude', 'longitude'], $locs);

    $users = [['admin@astanait.edu.kz', $adminHash, 'Campus Security', 'admin', 0, $ts($daysAgo(200))]];
    for ($i = 0; $i < 40; $i++) {
        $f = $first[$i % count($first)]; $l = $last[($i * 7) % count($last)];
        $users[] = [strtolower("$f.$l" . ($i + 1) . '@astanait.edu.kz'), $studentHash, "$f $l", 'student', $i === 39 ? 1 : 0, $ts($daysAgo(mt_rand(5, 190)))];
    }
    $insert('users', ['email', 'password_hash', 'full_name', 'role', 'is_blocked', 'created_at'], $users);

    $items = [];
    for ($i = 0; $i < 120; $i++) {
        $cat = mt_rand(1, count($categories));
        [$title, $desc] = $pick($things[$categories[$cat - 1]]);
        $age = mt_rand(0, 80);
        $resolved = (mt_rand() / mt_getrandmax()) < 0.35 && $age > 2;
        $items[] = [mt_rand(2, 40), $cat, mt_rand(1, count($locs)), mt_rand(0, 1) ? 'lost' : 'found', $title, $desc, $dt($daysAgo($age)), $resolved ? 'resolved' : 'open', null, $ts($daysAgo($age))];
    }
    $insert('items', ['user_id', 'category_id', 'location_id', 'item_type', 'title', 'description', 'event_date', 'status', 'photo_url', 'created_at'], $items);

    $messages = [];
    foreach ($pdo->query('SELECT item_id, user_id FROM items ORDER BY item_id LIMIT 60')->fetchAll() as $o) {
        do { $sender = mt_rand(2, 41); } while ($sender === (int) $o['user_id']);
        $messages[] = [$o['item_id'], $sender, $o['user_id'], $pick($msgs), $ts($daysAgo(mt_rand(0, 30)))];
    }
    $insert('messages', ['item_id', 'sender_id', 'receiver_id', 'body', 'sent_at'], $messages);

    $mrows = $pdo->query('SELECT message_id, receiver_id FROM messages ORDER BY message_id LIMIT 45')->fetchAll();
    $insert('notifications', ['user_id', 'message_id', 'type', 'is_read', 'created_at'],
        array_map(fn($m) => [$m['receiver_id'], $m['message_id'], 'reply', mt_rand(0, 1), $ts($daysAgo(mt_rand(0, 30)))], $mrows));

    $reports = [];
    for ($i = 0; $i < 20; $i++) $reports[] = [mt_rand(1, 120), mt_rand(2, 41), $pick($reasons), $pick(['new', 'reviewed']), $ts($daysAgo(mt_rand(0, 40)))];
    $insert('reports', ['item_id', 'reporter_id', 'reason', 'status', 'created_at'], $reports);

    $logs = [];
    for ($i = 0; $i < 15; $i++) {
        $a = $pick(['delete_post', 'block_user', 'unblock_user']);
        $logs[] = [1, mt_rand(1, 120), $a, $a === 'delete_post' ? 'Listing removed by moderator' : 'Account status changed after reports', $ts($daysAgo(mt_rand(0, 60)))];
    }
    $insert('admin_logs', ['admin_id', 'item_id', 'action', 'details', 'created_at'], $logs);

    $counts = [];
    foreach (['users', 'categories', 'locations', 'items', 'messages', 'notifications', 'reports', 'admin_logs'] as $t)
        $counts[$t] = (int) $pdo->query("SELECT COUNT(*) FROM $t")->fetchColumn();
    return $counts;
}
